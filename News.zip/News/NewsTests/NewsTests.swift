//
//  NewsTests.swift
//  NewsTests
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import XCTest
@testable import News

final class NewsTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

    func testNewsParametersAndData() {
        
        let viewModel = NewsListViewModel()
        
        //Check that parameters are not nil
        XCTAssertNotNil(viewModel.parameters, "Parameters shouldn't be nil")
        
        //Expectation for loading news
        let expectation = XCTestExpectation(
          description: "Loading news")
        
        //Wait for async loading to complete
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            // Assert for response date is not empty
            XCTAssertFalse(viewModel.news.isEmpty, "News shouldn't be empty")
            // verify the title for the first article
            if let firsArticle = viewModel.news.first {
                XCTAssertFalse(firsArticle.title.isEmpty,"Article should have a title")
            }
            // verify the url for the first article
            if let firsArticle = viewModel.news.first {
                XCTAssertFalse(firsArticle.url.isEmpty,"Article should have an url")
            }
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 8)
    }
}
