//
//  Helpers.swift
//  News
//
//  Created by ASKI Soukaina on 05/03/2026.
//

import Foundation


func startTimer(after sec: Double, action: @escaping() -> Void){
    DispatchQueue.main.asyncAfter(deadline: .now() + sec){
        action()
    }
}

func dateFormatter(_ date:Date, dateFormat:String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = dateFormat
    return dateFormatter.string(from: date)
}

