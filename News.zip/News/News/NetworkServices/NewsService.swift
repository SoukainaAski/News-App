//
//  NewsService.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import Foundation

enum NewsError: Error
{
    case noData
    case failedRequest
    case invalidResponse
    case invalidData
    case badRequest
    case Unauthorized
    case TooManyRequests
    case ServerError
}

class NewsService {
    
    private static let apiKey = "d0e7887c09364ddfa76f9b8fd20aaff1"
    private static let pathUrl = "https://newsapi.org/v2/top-headlines?"
    
    typealias newsDataCompletion = (NewsData?, NewsError?) -> ()
    
    static func fetchNews(with parameters:[String : String], completion: @escaping newsDataCompletion)
    {
        var components = URLComponents(string: pathUrl)
        components?.queryItems =
        parameters.map{
            URLQueryItem(name: $0.key, value: $0.value)
        }
        components?.queryItems?.append(URLQueryItem(name: "apiKey", value: apiKey))
        
        guard let url = components?.url else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            //execute completion handler on main thread
            DispatchQueue.main.async {
                guard error == nil else {
                    print("Failed request: \(error!.localizedDescription)")
                    completion(nil,.failedRequest)
                    return
                }
                
                guard let data = data else {
                    print("No data returned")
                    completion(nil, .noData)
                    return
                }
                
                guard let response = response as? HTTPURLResponse else {
                    print("Invalid response")
                    completion(nil, .invalidResponse)
                    return
                }
                
                switch response.statusCode
                {
                case 400:
                    print("Bad Request status")
                    completion(nil, .badRequest)
                case 401:
                    print("Unauthorized status")
                    completion(nil, .Unauthorized)
                case 429:
                    print("Too Many Requests status")
                    completion(nil, .TooManyRequests)
                case 500:
                    print("Something went wrong status")
                    completion(nil, .ServerError)
                case 200:
                    do {
                        let decoder = JSONDecoder()
                        decoder.dateDecodingStrategy = .iso8601
                        let newsData : NewsData = try decoder.decode(NewsData.self, from: data)
                        completion(newsData,nil)
                    } catch let DecodingError.keyNotFound(key, context) {
                        print("keyNotFound: '\(key.stringValue)' not found for \(context.codingPath).")
                        completion(nil, .invalidData)
                    } catch let DecodingError.dataCorrupted(context) {
                        print("dataCorrupted: data corrupted. \(context.debugDescription)")
                        completion(nil, .invalidData)
                    } catch let DecodingError.typeMismatch(type, context) {
                        print("typeMismatch: type mismatch of \(type) in \(context.debugDescription)")
                        completion(nil, .invalidData)
                    } catch let DecodingError.valueNotFound(type, context) {
                        print("valueNotFound: value not found for \(type). \(context.debugDescription)")
                        completion(nil, .invalidData)
                    } catch {
                        print(error.localizedDescription)
                        completion(nil, .invalidData)
                    }
                    
                default:
                    break
                }
            }
        }.resume()
    }
    
}
