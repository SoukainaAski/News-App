//
//  NewsApp.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import SwiftUI

@main
struct NewsApp: App {
    var body: some Scene {
        WindowGroup {
            NewsListView()
        }
    }
}
