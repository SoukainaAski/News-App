//
//  NewsListViewModel.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import Foundation

class NewsListViewModel: ObservableObject {
    
    @Published var news: [NewsData.Article] = []
    var parameters : [String:String] = [:]
    init() {
        parameters = ["country" : "us"]
        self.getNews()
    }
    
    func getNews(){
        NewsService.fetchNews(with: parameters) { [weak self] (newsData, error) in
            guard let self = self,
                  let newsData = newsData
            else {
                return
            }
            self.news = newsData.articles
            
        }
    }
}
