//
//  NewsData.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import Foundation

struct NewsData:Decodable {
    
    var status : String
    var totalResults : Int
    var articles : [Article]
    
    struct Article:Decodable,Identifiable
    {
        var id : String {url}
        let source : Source
        
        struct Source:Decodable {
            let id : String?
            let name : String
        }
        
        let author : String?
        let title : String
        let description : String?
        let url : String
        let urlToImage : String?
        let publishedAt : Date
        let content : String?
    }
    
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        status = try values.decode(String.self, forKey: .status)
        totalResults = try values.decode(Int.self, forKey: .totalResults)
        articles = try values.decode([Article].self, forKey: .articles)
    }
    
    enum CodingKeys: String, CodingKey {
        case status,totalResults,articles
    }
}
