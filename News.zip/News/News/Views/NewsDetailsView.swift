//
//  NewsDetailsView.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import SwiftUI

struct NewsDetailsView: View {
    let article : NewsData.Article
    
    @State private var isTimeout = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                AsyncImage(url: URL(string: article.urlToImage ?? "")) { phase in
                    switch phase {
                    case .empty:
                        VStack {
                            ProgressView()
                            if isTimeout {
                                Text("No image found")
                            }
                        }.onAppear {
                            startTimer(after: 5){
                                isTimeout = true
                            }
                        }
                    case .success(let image):
                        image.resizable()
                            .scaledToFill()
                    case .failure:
                        Text("No image found")
                    default:
                        EmptyView()
                    }
                }
                
                Text(article.title)
                    .font(.title)
                    .bold()
                
                Text(article.description ?? "No description available")
                    .font(.body)
                
                Spacer()
                
                if let urlLink = URL(string: article.url) {
                    Link(destination: urlLink){
                        Text("Read full article")
                            .foregroundColor(.blue)
                            .underline(color: .blue)
                    }.padding(.top,15)
                }
            }.padding()
        }
    }
}

