//
//  NewsListView.swift
//  News
//
//  Created by ASKI Soukaina on 04/03/2026.
//

import SwiftUI

struct NewsListView: View {
    @StateObject private var viewModel = NewsListViewModel()
    
    var body: some View {
        NavigationStack {
            List(viewModel.news){ article in
                ArticleCell(article: article)
            }
            .navigationTitle("Top News")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}


#if DEBUG
struct NewsListView_Previews: PreviewProvider {
    static var previews: some View {
        NewsListView()
    }
}
#endif

struct ArticleCell: View {
    
    let article : NewsData.Article
    
    @State private var isTimeout = false
    
    var body: some View {
        
        return  NavigationLink(destination: NewsDetailsView(article: article)) {
            HStack(spacing: 10){
                
                AsyncImage(url: URL(string: article.urlToImage ?? "")) { phase in
                    switch phase {
                    case .empty:
                        VStack {
                            ProgressView()
                            if isTimeout {
                                Text("No image found")
                            }
                        }.onAppear {
                            startTimer(after: 5){
                                isTimeout = true
                            }
                        }
                    case .success(let image):
                        image.resizable()
                            .scaledToFill()
                    case .failure:
                        Text("No image found")
                    default:
                        EmptyView()
                    }
                }
                .frame(width: 80, height: 80)
                .cornerRadius(8.0)
                
                VStack(spacing: 10) {
                    Text(article.title)
                        .font(.headline)
                    Text("published At : \(dateFormatter(article.publishedAt, dateFormat:"yyyy-MM-dd HH:mm:ss"))")
                        .font(.footnote)
                }
            }
            .padding(.vertical, 8)
        }
    }
}
