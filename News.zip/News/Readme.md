#  Description
This mini project is a News app built in SwiftUI framework following the MVVM architecture.
It consumes the https://newsapi.org/docs Top headlines api to display a list of news articles.
Users can:
 *View a list of news headlines with images and published date.
 *Select a news items to navigate to a detail screen showing:
    -The image of the news
    -Title and description
    -A link to full article
    
# Features
*Fetch news dynamically from News API
*Display list of articles in a List view
*Nvigate to a detail screen for each article
*Loading images asynchrounsly 
*MVVM architecture with:
    - Model :News data
    - ViewModel : Handles API fetching
    - View : swiftUI views for news list and details

# Challenges
1.No visuals/design: The UI is basic because there were no design reference
2.Error handling with API: maybe display alerts
3.No Launch Screen: The app do not have a launch screen
4.Unit Testing: -Not familiar with unit testing - Creating a simple test to ensure viewModel fetches articles correctly 

# Future Improvements
*Add a Launch Screen
*Add more UI and business logic features to the app , like: filtering news results - add some articles to favorite - zoom/resize the detail image on tap
*Show error messages to the user
*Implement caching of images
*Create more unit and UI tests
